<?php 
// Include the database config file 
include_once './dbconnect.php'; 
 
if(!empty($_POST["catid"])){ 
    // Fetch state data based on the specific country 
    $catid= $_POST['catid'];
    $query = "SELECT * FROM subcategory,category WHERE subcategory.category_id = $catid and subcategory.category_id = category.category_id ";
    $result = $conn->query($query); 
    $count=1;
    ?>
    <thead>
        <tr class="tm-bg-white">
        <th scope="col">S.N</th>
        <th scope="col" class="text-center">Sub Category</th>
        <th scope="col" class="text-center">Category</th>
        <th scope="col" class="text-center">Action</th>
        </tr>
    </thead>
    <?php
    if($result->num_rows > 0){ 
        while($row = $result->fetch_assoc()){ 
            ?> 
            
            <tr>
            <td><?=$count?></td>
            <td><?=$row['sub_category_name']?></td>   
            <td><?=$row['category_name']?></td>   
            <td><a href="edit-subcategory.php?id=<?=$row['sub_category_id']?>" class="btn btn-small btn-primary">Edit</a></td>
            </tr>

            <?php
            $count=$count+1;
    } 
    }else{ 
        echo '<option >Sub category not available</option>'; 
    } 
}
?>
