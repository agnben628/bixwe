<?php

    include_once "../config/dbconnect.php";
    
    $sc_id=$_POST['record'];
    $query="DELETE FROM sub_category where sub_category_id='$sc_id'";

    $data=mysqli_query($conn,$query);

    if($data){
        echo"Category Item Deleted";
    }
    else{
        echo"Not able to delete";
    }
    
?>