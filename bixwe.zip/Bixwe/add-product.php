<?php    
    include "./dbconnect.php";
    
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600">
    <!-- https://fonts.google.com/specimen/Open+Sans -->
    <link rel="stylesheet" href="adfontawesome.min.css">
    <!-- https://fontawesome.com/ -->
    <link rel="stylesheet" href="adfullcalendar.min.css">
    <!-- https://fullcalendar.io/ -->
    <link rel="stylesheet" href="adbootstrap.min.css">
    <!-- https://getbootstrap.com/ -->
    <link rel="stylesheet" href="admin.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
       <link rel="stylesheet" href="style.css"></link>
       <script type="text/javascript" src="./ajaxWork.js"></script>    
    <script type="text/javascript" src="./script.js"></script>
    <script src="https://code.jquery.com/jquery-3.1.1.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"></script>
</head>

<body id="reportsPage">
    <div class="" id="home">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav class="navbar navbar-expand-xl navbar-light bg-light">
                        <a class="navbar-brand" href="./admin_index.php">
                            <h3 class="tm-site-title mb-0">Dashboard</h3>
                        </a>
                        <button class="navbar-toggler ml-auto mr-0" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link d-flex" href="customers.php">
                                        <span>Customers</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link d-flex" href="categories.php">
                                        <span>Category</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link d-flex" href="product.php">
                                        <span>Product</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link d-flex" href="orders.php">
                                        <span>Orders</span>
                                    </a>
                                </li>
                                &emsp;&emsp;&emsp;&emsp;
                                <li class="nav-item">
                                    <a class="nav-link d-flex" href="logout.php">
                                        <span>Logout</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        <!-- row -->
        <div class="row tm-mt-big">
            <div class="col-xl-8 col-lg-10 col-md-12 col-sm-12">
                <div class="bg-white tm-block">
                    <div class="row">
                        <div class="col-12">
                            <h2 class="tm-block-title d-inline-block">Add Product</h2>
                        </div>
                    </div>
                    <div class="row mt-4 tm-edit-product-row">
                        <div class="col-xl-7 col-lg-7 col-md-12">
                            <form enctype='multipart/form-data' action="./add-product.php" method="POST" class="tm-edit-product-form">
                                <div class="input-group mb-3">
                                    <label for="category" class="col-xl-4 col-lg-4 col-md-4 col-sm-5 col-form-label">Category</label>
                                    <select class="custom-select col-xl-9 col-lg-8 col-md-8 col-sm-7" name="category" id="category">
                                        <option disabled selected>Select Category</option>
                                            <?php
                                            $sql="SELECT * from category";
                                            $result = $conn-> query($sql);

                                            if ($result-> num_rows > 0){
                                            while($row = $result-> fetch_assoc()){
                                            echo "<option value='".$row['category_id']."'>".$row['category_name'] ."</option>";
                                            }
                                            }
                                            ?>
                                    </select>
                                </div>
                                <div class="input-group mb-3">
                                    <label for="subcategory" class="col-xl-4 col-lg-4 col-md-4 col-sm-5 col-form-label">Sub Category</label>
                                    <select class="custom-select col-xl-9 col-lg-8 col-md-8 col-sm-7" name="subcategory" id="subcategory">
                                        <option disabled selected>Select Sub Category</option>
                                        
                                    </select>
                                </div>
                                <div class="input-group mb-3">
                                    <label for="name" class="col-xl-4 col-lg-4 col-md-4 col-sm-5 col-form-label">Name</label>
                                    <input id="p_name" name="p_name" type="text"class="form-control validate col-xl-9 col-lg-8 col-md-8 col-sm-7" required pattern="^\S[a-zA-Z\s]*$">
                                </div>
                                <div class="input-group mb-3">
                                    <label for="description" class="col-xl-4 col-lg-4 col-md-4 col-sm-5 mb-2">Description</label>
                                    <textarea id="p_desc" name="p_desc" class="form-control validate col-xl-9 col-lg-8 col-md-8 col-sm-7" rows="3" required pattern="^\S[a-zA-Z\s]*$"></textarea>
                                </div>
                                <div class="input-group mb-3">
                                    <label for="price" class="col-xl-4 col-lg-4 col-md-4 col-sm-5 col-form-label" >Price</label>
                                    <input id="p_price" name="p_price" type="number" class="form-control validate col-xl-9 col-lg-8 col-md-8 col-sm-7" min="1" required pattern="^\-[0-9]+">
                                </div>
                                <div class="input-group mb-3">
                                    <label for="qty" class="col-xl-4 col-lg-4 col-md-4 col-sm-5 col-form-label">Quantity</label>
                                    <input id="qty" name="qty" type="number" class="form-control validate col-xl-9 col-lg-8 col-md-8 col-sm-7" min="1" required pattern="^[0-9]+">
                                </div>
                                <div class="input-group mb-3">
                                    <label for="file1"class="col-xl-4 col-lg-4 col-md-4 col-sm-5 col-form-label">Image 1</label>
                                    <input type="file" class="form-control validate col-xl-9 col-lg-8 col-md-8 col-sm-7-file" id="file1" name="file1">
                                </div>
                                <div class="input-group mb-3">
                                    <label for="file2"class="col-xl-4 col-lg-4 col-md-4 col-sm-5 col-form-label">Image 2</label>
                                    <input type="file" class="form-control validate col-xl-9 col-lg-8 col-md-8 col-sm-7-file" id="file2" name="file2">
                                </div>
                                <div class="input-group mb-3">
                                    <label for="file3"class="col-xl-4 col-lg-4 col-md-4 col-sm-5 col-form-label">Image 3</label>
                                    <input type="file" class="form-control validate col-xl-9 col-lg-8 col-md-8 col-sm-7-file" id="file3" name="file3">
                                </div>
                                <div class="input-group mb-3">
                                    <div class="ml-auto col-xl-8 col-lg-8 col-md-8 col-sm-7 pl-0">
                                        <button type="submit" class="btn btn-primary" id="upload" name="upload">Add</button>
                                    </div>
                                </div>
                            </form>
                            <div class="ml-auto col-xl-10 col-lg-8 col-md-10 col-sm-7 pl-0">
                                <a href="add-productvariation.php" class="btn btn-small btn-primary">Add New Variations of Products</a>
                            </div>
                    </div>
                </div>
            </div>
        </div>
        <footer class="row tm-mt-big">
            <div class="col-12 font-weight-light">
            </div>
        </footer>
    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <!-- https://jquery.com/download/ -->
    <script src="jquery-ui-datepicker/jquery-ui.min.js"></script>
    <!-- https://jqueryui.com/download/ -->
    <script src="js/bootstrap.min.js"></script>
    <!-- https://getbootstrap.com/ -->
    <script>
        $(function () {
            $('#expire_date').datepicker();
        });
       
        $(document).ready(function(){
            $('#category').on('change', function(){
                var catID = $(this).val();
                if(catID){
                    $.ajax({
                        type:'POST',
                        url:'ajaxsubcat.php',
                        data:'catid='+catID,
                        success:function(html){
                            $('#subcategory').html(html); 
                        }
                    }); 
                }else{
                    $('#subcategory').html('<option value="">Select category first</option>');
                }
            });
            
        });

    </script>
    <?php
    include_once "./dbconnect.php";
    
    if(isset($_POST['upload']))
    {
       
        $ProductName = $_POST['p_name'];
        $desc= $_POST['p_desc'];
        $price = $_POST['p_price'];
        $category = $_POST['category'];
        $sub_category = $_POST['subcategory'];
        $qty = $_POST['qty'];
            
        $name1 = $_FILES['file1']['name'];
        $temp1 = $_FILES['file1']['tmp_name'];
    
        $location="./uploads/";
        $image1=$location.$name1;

        $target_dir="./uploads/";
        $finalImage1=$target_dir.$name1;

        move_uploaded_file($temp1,$finalImage1);
        $name2 = $_FILES['file2']['name'];
        $temp2 = $_FILES['file2']['tmp_name'];
    
        $location="./uploads/";
        $image2=$location.$name2;

        $target_dir="./uploads/";
        $finalImage2=$target_dir.$name2;

        move_uploaded_file($temp2,$finalImage2);
        $name3 = $_FILES['file3']['name'];
        $temp3 = $_FILES['file3']['tmp_name'];
        $location="./uploads/";
        $image3=$location.$name3;

        $target_dir="./uploads/";
        $finalImage3=$target_dir.$name3;

        move_uploaded_file($temp3,$finalImage3);

        $insert = mysqli_query($conn,"INSERT INTO product (product_name,product_desc,image1,image2,image3,price,category_id,sub_category_id, total_quantity) VALUES ('$ProductName','$desc','$finalImage1','$finalImage2','$finalImage3',$price,$category,$sub_category, $qty)");
 
        if($insert)
        {
        echo "<p id='d' style='color:white;'>" ."Product added succesfully"."</p>" ;
        }
        else
        {
        echo "<p id='d' style='color:white;'>" ."Could not add product"."</p>" ;
        }
     
    }
        
?>
</body>

</html>
