<?php
   session_start();
   include_once "./dbconnect.php";
?>
       
 <!-- nav -->
 <nav  class="navbar navbar-expand-lg navbar-light px-5" style="background-color: #afb0b3;">
    
    <a class="navbar-brand ml-5" href="admin_index.php">
    <h4 id="text" style="color: #111212"><strong><span>Bix</span>we</strong></h4>
    </a>      
</nav>
