<?php
include "./dbconnect.php"
if(isset($_POST['get_option']))
{


 $product_name = $_POST['get_option'];
 $sel = mysqli_query($conn,"SELECT quantity from product where product_name='$product_name'");
 while($row=mysqli_fetch_array($sel))
 {
  echo "<input id='tqty' value='$row['quantity']'></input>";
 }
 exit;
}
?>