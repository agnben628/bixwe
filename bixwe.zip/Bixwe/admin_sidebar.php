<!-- Sidebar -->
<head>
<link rel="stylesheet" href="./style.css"></link>
</head>
<div class="sidebar" id="mySidebar"style="background-color:#f5f3ed;">
<div class="side-header">
    <h5 style="margin-top:10px;color: #111212">Hello, Admin</h5>
</div>

<hr style="border:1px solid; background-color:#f5f3ed; border-color:#f5f3ed;">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()" style="color: #111212; background-color:#f5f3ed;">×</a>
    <a href="./admin_index.php" style="color: #111212"><i class="fa fa-home"style="color: #6c8080"></i> Dashboard</a>
    <a href="customers.php"  onclick="showCustomers()" style="color: #111212"><i class="fa fa-users" style="color: #6c8080"></i> Customers</a>
    <a href="categories.php"   onclick="showCategory()" style="color: #111212"><i class="fa fa-th-large" style="color: #6c8080"></i> Category</a>
    <a href="product.php"   onclick="showProductItems()" style="color: #111212"><i class="fa fa-th" style="color: #6c8080"></i> Products</a>
    <a href="orders.php" onclick="showOrders()" style="color: #111212"><i class="fa fa-list" style="color: #6c8080"></i> Orders</a>
</div>
 
<div id="main">
    <button class="openbtn" onclick="openNav()" style="color: #111212; background-color:#f5f3ed;"><i class="fa fa-home" style="color: #111212"></i></button>
</div>


