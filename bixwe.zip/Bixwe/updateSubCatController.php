<?php
    include_once "../config/dbconnect.php";
    $sub_category_id=$_POST['sub_category_id'];
    $category_id=$_POST['category_id'];
    $sub_category_name= $_POST['sub_category_name'];
    $updateSubCat1 = mysqli_query($conn,"UPDATE sub_category SET category_id=$category_id WHERE sub_category_id=$sub_category_id");
    $updateSubCat2 = mysqli_query($conn,"UPDATE sub_category SET sub_category_name='$sub_category_name' WHERE sub_category_id=$sub_category_id");


    if($updateSubCat1 && $updateSubCat2)
    {
        header("Location: ../admin_index.php?subcategory=success");
    }
     else
     {
        header("Location: ../admin_index.php?subcategory=error");
     }
?>