
function openNav() {
  document.getElementById("mySidebar").style.width = "200px";
  document.getElementById("main").style.marginLeft = "200px";  
  document.getElementById("main-content").style.marginLeft = "200px";
  document.getElementById("main").style.marginRight = "200px";  
  document.getElementById("main-content").style.marginRight = "200px";
  document.getElementById("main").style.display="none";
}

function closeNav() {
  document.getElementById("mySidebar").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";  
  document.getElementById("main").style.display="block";  
}