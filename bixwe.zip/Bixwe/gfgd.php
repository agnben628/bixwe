<?php 
                            if($row["order_status"]==0)
                            {

                        ?>
                            <td><button class="btn btn-danger" onclick="ChangeOrderStatus('<?=$row['order_id']?>')">Pending </button></td>
                        <?php

                            }
                            else
                            {
                                ?>
                                <td><button class="btn btn-success" onclick="ChangeOrderStatus('<?=$row['order_id']?>')">Delivered</button></td>

                                <?php
                            }
                            if($row["pay_status"]==0)
                            {
                                ?>
                                <td><button class="btn btn-danger"  onclick="ChangePay('<?=$row['order_id']?>')">Unpaid</button></td>
                                <?php

                            }   
                            else if($row["pay_status"]==1)
                            {
                                ?>
                                <td><button class="btn btn-success" onclick="ChangePay('<?=$row['order_id']?>')">Paid </button></td>
                                <?php
                            }
                                ?>
                                <td><a class="btn btn-primary openPopup" data-href="./adminView/viewEachOrder.php?orderID=<?=$row['order_id']?>" href="javascript:void(0);">View</a></td>
                                </tr>
                                <?php
                                }
                            }
                            ?>