<?php 
session_start();
include_once "./dbconnect.php";
$category=$_GET['category'];
?>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">

        <title>Products</title>

        <!-- CSS FILES -->
        <link rel="preconnect" href="https://fonts.googleapis.com">

        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;300;400;700;900&display=swap" rel="stylesheet">

        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-icons.css" rel="stylesheet">
        <link rel="stylesheet" href="prostyle.css">
        <link rel="stylesheet" href="css/slick.css"/>
        <link href="stylecat.css" rel="stylesheet">
        <link rel="stylesheet" href="navstyle.css">
        <link rel="stylesheet"href="buttonstyle.css">
        <link href="style-homepage.css" rel="stylesheet">

    </head>
    
    <body>

        <section class="preloader">
            <div class="spinner">
                <span class="sk-inner-circle"></span>
            </div>
        </section>
    
        <main>


        <nav class="navbar navbar-expand-lg" id="nav1">
                <div class="container">
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <a class="navbar-brand" href="homepage.php">
                        <strong><span>Bix</span>we</strong>
                    </a>
                    &emsp;&emsp;
                    <div class="d-lg-none">

                    <div class="navbar-nav dropdown">
                            <?php
                            $sql="SELECT * from category";
                            $result = $conn-> query($sql);

                            if ($result-> num_rows > 0){
                                while($row = $result-> fetch_assoc()){

                            ?>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="category.php?category=<?php echo $row['category_id'];?>" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                    <?php echo $row['category_name']; 
                                    ?>
                                    </a>
                                    <?php $cat=$row['category_id'];?>
                                    
                                    
                                </li>
                                
                                <?php
                                    }
                                }
                                ?>
                                
                    
                    </div>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
                <form class="form-inline">
                <input type="search" class="form-control ds-input" id="search-input" placeholder="Search..." aria-label="Search for..." autocomplete="off" spellcheck="false" 
            role="combobox" aria-autocomplete="list" aria-expanded="false" aria-owns="algolia-autocomplete-listbox-0" dir="auto" style="position: relative; vertical-align: top;">
                </form>
                &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
                <a href="curate.php" class="bi bi-collection custom-icon me-5"></a>
                <a href="cart.php" class="bi bi-cart2 custom-icon me-5"></a>
                <a href="profile.php" class="bi-person custom-icon me-5"></a>

                    </div>

                    <div class="collapse navbar-collapse" id="navbarNav">
                    &emsp;&emsp;
                    <ul class="navbar-nav">
                            <?php
                            $sql="SELECT * from category";
                            $result = $conn-> query($sql);

                            if ($result-> num_rows > 0){
                                while($row = $result-> fetch_assoc()){

                            ?>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="category.php?category=<?php echo $row['category_id'];?>" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <?php echo $row['category_name']; 
                                    ?>
                                    </a>
                                    <?php $cat=$row['category_id'];?>
                                    
                                    
                                </li>
                                
                                <?php
                                    }
                                }
                                ?>
                                
                            </ul>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
                            <form class="form-inline">
                                <input type="search" class="form-control ds-input" id="search-input" placeholder="Search..." aria-label="Search for..." autocomplete="off" spellcheck="false" 
                            role="combobox" aria-autocomplete="list" aria-expanded="false" aria-owns="algolia-autocomplete-listbox-0" dir="auto" style="position: relative; vertical-align: top;">
                                </form>
                            &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
                            <a href="curate.php" class="bi bi-collection custom-icon me-5"></a>
                            <a href="cart.php" class="bi bi-cart2 custom-icon me-5"></a>
                        <a href="profile.php" class="bi-person custom-icon me-5"></a>

                        </div>
                    </div>
                </div>
            </nav>     
                     
            <section class="products section-padding d-flex">
                <div class="container">
                    <div class="col-6">
                    <ul>
                        <div class="bottom_nav">
                            <div class="dropdown">
                                <button class="dropbtn">Filter</button>
                                <select id ="subcatsel" name="subcatsel"class="dropdown-content">
                                    <?php
                                        $sql="SELECT * from subcategory where category_id='$category'";
                                        $result = $conn-> query($sql);
                                        if ($result-> num_rows > 0){
                                        while($row = $result-> fetch_assoc()){
                                    ?>
                                    <option value = "<?php echo $row['sub_category_id'];?>"><?php echo  $row['sub_category_name']; ?></option>
                                    <?php
                                        }
                                        }
                                    ?> 
                                </select>
                            </div>
                        </div>
                    </ul>
                    </div>
                    </br></br></br></br>
                    <div class="col-lg-4 col-6 mb-3 d-flex"> 
                        <table id="product"> 
                            <?php
                                $sql="SELECT * from product where category_id='$category'";
                                $result = $conn-> query($sql);
                                $count = 0;
                                if ($result-> num_rows > 0){
                                    while($row = $result-> fetch_assoc()){ 
                                        if($count==6)
                                        {
                                            echo "</tr>";
                                            $count = 0;
                                        }
                                        if($count==0)
                                        echo "<tr>";
                                        echo "<td  style='padding: 10px 20px 10px 20px; margin: 10px 20px 10px 20px;'>";
                            ?>
                            <div class="product-thumb">
                                <div >
                                    <img src= " <?php echo $row['image1']?>"class="img-fluid product-image" alt="" width="550px" height="550px">
                                </div>
                                <div class="product-top d-flex">
                                    <a href="#" class="bi-heart-fill product-icon"></a>
                                </div>
                                <div class="product-info d-flex">
                                    <div>
                                        <p class="product-title mb-0">
                                            <a href="product-detail.php?products=<?php echo $row['product_id'];?>" class="product-title-link"><?php echo $row['product_name']?></a>
                                        </p>
                                        <p class="product-price text-muted ms-auto">₹ <?php echo $row['price']?></p> 
                                    </div>
                                </div>
                            </div>
                            <?php
                                $count++;
                                echo"</td>";
                                }
                                }
                                if($count>0)
                                echo "</tr>";
                            ?>
                        </table>
                    </div>
                </div>
                 
            </section>  
            

        </main>

        <footer class="site-footer">
            <div class="container">
                <div class="row">

                    <div class="col-lg-3 col-10 me-auto mb-4">
                        <h4 class="text-white mb-3"><a href="homepage.php">Bix</a>we</h4>
                        <p class="copyright-text text-muted mt-lg-5 mb-4 mb-lg-0">Copyright © 2022 <strong>Bixwe</strong></p>
                        <br>
                    </div>

                    <div class="col-lg-5 col-8">
                        <h5 class="text-white mb-3">Sitemap</h5>

                        <ul class="footer-menu d-flex flex-wrap">
                            <li class="footer-menu-item"><a href="about.html" class="footer-menu-link">Story</a></li>

                            <li class="footer-menu-item"><a href="products.php" class="footer-menu-link">Products</a></li>

                            <li class="footer-menu-item"><a href="#" class="footer-menu-link">Privacy policy</a></li>

                            <li class="footer-menu-item"><a href="#" class="footer-menu-link">FAQs</a></li>

                            <li class="footer-menu-item"><a href="#" class="footer-menu-link">Contact</a></li>
                        </ul>
                    </div>

                    <div class="col-lg-3 col-4">
                        <h5 class="text-white mb-3">Social</h5>

                        <ul class="social-icon">

                            <li><a href="#" class="social-icon-link bi-youtube"></a></li>

                            <li><a href="#" class="social-icon-link bi-whatsapp"></a></li>

                            <li><a href="#" class="social-icon-link bi-instagram"></a></li>

                            <li><a href="#" class="social-icon-link bi-skype"></a></li>
                        </ul>
                    </div>

                </div>
            </div>
        </footer>


        <!-- JAVASCRIPT FILES -->
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/Headroom.js"></script>
        <script src="js/jQuery.headroom.js"></script>
        <script src="js/slick.min.js"></script>
        <script src="js/custom.js"></script>
        <script>

       
$(document).ready(function(){
    $('#subcatsel').on('change', function(){
        var subcatID = $(this).val();
        if(subcatID){
            $.ajax({
                type:'POST',
                url:'changesubcat.php',
                data:'subcatid='+subcatID,
                success:function(html){
                    $('#product').html(html); 
                }
            }); 
        }else{
            
        }
    });
    
});
    </script>
        
    </body>
</html>







