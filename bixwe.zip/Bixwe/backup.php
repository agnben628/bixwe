<div class="col-lg-4 col-12 mb-3">
                            <div class="product-thumb">
                                <a href="shop.php">
                                <?php
                                $sql="SELECT * from product, category where product_id=10 and product.category_id=category.category_id";
                                $result = $con-> query($sql);

                                if ($result-> num_rows > 0){
                                while($row = $result-> fetch_assoc()){ 
                                    ?>
                                    <img src="<?=$row['product_image'];?>" class="img-fluid product-image" alt="">
                                </a>

                                <div class="product-top d-flex">
                                    <span class="product-alert me-auto"><?php echo $row['category_name'];?></span>

                                    <a href="#" class="bi-heart-fill product-icon"></a>
                                </div>

                                <div class="product-info d-flex">
                                    <div>
                                        <h5 class="product-title mb-0">
                                            <a href="shop.php?products=<?php echo $row['product_id']?>" class="product-title-link"><?php echo $row['product_name'];?></a>
                                        </h5>

                                        <p class="product-p"></p>
                                    </div>

                                    <small class="product-price text-muted ms-auto mt-auto mb-5">₹ <?php echo $row['price'];?></small>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                }
            
            ?>      
                        <div class="col-lg-4 col-12 mb-3">
                            <div class="product-thumb">
                                <a href="shop.php">
                                <?php
                                $sql="SELECT * from product, category where product_id=14 and product.category_id=category.category_id";
                                $result = $con-> query($sql);

                                if ($result-> num_rows > 0){
                                while($row = $result-> fetch_assoc()){ 
                                    ?>
                                    <img src="<?php echo $row['product_image'];?>" class="img-fluid product-image" alt="">
                                </a>

                                <div class="product-top d-flex">
                                    <span class="product-alert me-auto"><?php echo $row['category_name'];?></span>

                                    <a href="#" class="bi-heart-fill product-icon"></a>
                                </div>

                                <div class="product-info d-flex">
                                    <div>
                                        <h5 class="product-title mb-0">
                                            <a href="shop.php?products=<?php echo $row['product_id']?>" class="product-title-link"><?php echo $row['product_name'];?></a>
                                        </h5>

                                        <p class="product-p"></p>
                                    </div>

                                    <small class="product-price text-muted ms-auto mt-auto mb-5">₹ <?php echo $row['price'];?></small>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                }
            
            ?>      
                        <div class="col-lg-4 col-12 mb-3">
                            <div class="product-thumb">
                                <a href="shop.php">
                                <?php
                                $sql="SELECT * from product, category where product_id=15 and product.category_id=category.category_id";
                                $result = $con-> query($sql);

                                if ($result-> num_rows > 0){
                                while($row = $result-> fetch_assoc()){ 
                                    ?>
                                    <img src="<?php echo $row['product_image'];?>" class="img-fluid product-image" alt="">
                                </a>

                                <div class="product-top d-flex">
                                    <span class="product-alert me-auto"><?php echo $row['category_name'];?></span>

                                    <a href="#" class="bi-heart-fill product-icon"></a>
                                </div>

                                <div class="product-info d-flex">
                                    <div>
                                        <h5 class="product-title mb-0">
                                            <a href="shop.php?products=<?php echo $row['product_id']?>" class="product-title-link"><?php echo $row['product_name'];?></a>
                                        </h5>

                                        <p class="product-p"></p>
                                    </div>

                                    <small class="product-price text-muted ms-auto mt-auto mb-5">₹ <?php echo $row['price'];?></small>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                }
            
            ?>      