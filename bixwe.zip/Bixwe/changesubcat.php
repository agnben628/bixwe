<?php
    include_once './dbconnect.php'; 
    if(!empty($_POST["subcatid"]))
    {
        $subcatid= $_POST['subcatid'];
        $query = "SELECT * FROM product,subcategory WHERE product.sub_category_id = $subcatid and product.sub_category_id=subcategory.sub_category_id";
        $result = $conn->query($query); 
 
            $count = 0;
            if ($result-> num_rows > 0){
                while($row = $result-> fetch_assoc()){ 
                    if($count==6) 
                    {
                        echo "</tr>";
                        $count = 0;
                    }
                    if($count==0)
                    echo "<tr>";
                    echo "<td  style='padding: 10px 20px 10px 20px; margin: 10px 20px 10px 20px;'>";
        ?>
        <div class="product-thumb">
            <div >
                <img src= " <?php echo $row['image1']?>"class="img-fluid product-image" alt="" width="550px" height="550px">
            </div>
            <div class="product-top d-flex">
                <a href="#" class="bi-heart-fill product-icon"></a>
            </div>
            <div class="product-info d-flex">
                <div>
                    <p class="product-title mb-0">
                        <a href="product-detail.php?products=<?php echo $row['product_id'];?>" class="product-title-link"><?php echo $row['product_name']?></a>
                    </p>
                    <p class="product-price text-muted ms-auto">₹ <?php echo $row['price']?></p> 
                </div>
            </div>
        </div>
        <?php
            $count++;
            echo"</td>";
            }
            }
            if($count>0)
            echo "</tr>";
        
    }
?>