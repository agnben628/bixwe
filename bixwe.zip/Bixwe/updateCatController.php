<?php
    include_once "../config/dbconnect.php";

    $category_id=$_POST['category_id'];
    $category_name= $_POST['category_name'];
    $updateCat = mysqli_query($conn,"UPDATE category SET category_name='$category_name'WHERE category_id=$category_id");


    if($updateCat)
    {
        header("Location: ../admin_index.php?category=success");
    }
    else
    {
        header("Location: ../admin_index.php?category=error");
    }
?>