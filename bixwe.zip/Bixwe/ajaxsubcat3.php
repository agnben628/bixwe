<?php 
// Include the database config file 
include_once './dbconnect.php'; 
 
if(!empty($_POST["catid"])){ 
    // Fetch state data based on the specific country 
    $catid= $_POST['catid'];
    $query = "SELECT * FROM product,subcategory,category WHERE product.category_id = $catid and product.category_id=category.category_id AND product.sub_category_id=subcategory.sub_category_id" ;
    $result = $conn->query($query); 
    $count=1;
    ?>
    <thead class="tm-bg-grey">
        <tr class="tm-bg-white">
        <th scope="col">S.N</th>
        <th scope="col" class="text-center" colspan="3">Image</th>
        <th scope="col" class="text-center">Product</th>
        <th scope="col" class="text-center">Product Description</th>
        <th scope="col" class="text-center">Category</th>
        <th scope="col" class="text-center">Sub Category</th>
        <th scope="col" class="text-center">Price</th>
        <th scope="col" class="text-center">Quantity</th>
        <th scope="col" class="text-center">Action</th>
        </tr>
    </thead>
    <?php
    if($result->num_rows > 0){ 
        while($row = $result->fetch_assoc()){ 
            ?> 
            
            <tr>
            <td><?=$count?></td>
            <td><img height='80px' src='<?=$row["image1"]?>'></td>
            <td><img height='80px' src='<?=$row["image2"]?>'></td>
            <td><img height='80px' src='<?=$row["image3"]?>'></td>
            <td><?=$row["product_name"]?></td>
            <td><?=$row["product_desc"]?></td>      
            <td><?=$row["category_name"]?></td>
            <td><?=$row["sub_category_name"]?></td> 
            <td><?=$row["price"]?></td>  
            <td><?=$row["total_quantity"]?></td>     
            <td><a href="edit-product.php?id=<?=$row['product_id']?>" class="btn btn-small btn-primary">Edit</a></td>
            </tr>

            <?php
            $count=$count+1;
    } 
    }else{ 
        echo '<option >Product not available</option>'; 
    } 
}
?>
