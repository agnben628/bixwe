<div class="bottom_nav">
      <ul>
      <div class="bottom_nav">
                            <div class="dropdown">
                            <button class="dropbtn">Category</button>
                            <div class="dropdown-content">
                            <?php
                            include_once "connection.php";
                            $sql="SELECT * from subcategory";
                            $result = $conn-> query($sql);

                            if ($result-> num_rows > 0){
                                while($row = $result-> fetch_assoc()){

                                    ?>
                                
                                <a href="category.php?category=<?php echo $row['category_id'];?>&?subcategory=<?php echo $row['sub_category_id'];?>"> <?php echo  $row['sub_category_name']; ?></a>
                                
                                <?php
                                    }
                                }
                            
                            ?> 
      </ul>
  </div>

</div>       