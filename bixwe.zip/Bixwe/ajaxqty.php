<?php 
// Include the database config file 
include_once './dbconnect.php'; 
 
if(!empty($_POST["prodid"])){ 
    // Fetch state data based on the specific country 
    $prodid= $_POST['prodid'];
    $query = "SELECT * FROM product WHERE product_id = $prodid";
    $result = $conn->query($query); 
      
    if($result->num_rows > 0){ 
        while($row = $result->fetch_assoc()){  
            echo $row['total_quantity'];

        } 
    }else{ 
        echo 'Product not available'; 
    } 
}
?>
